$(document).ready(function(){
// following scroll function will give the header background white and box shadow when user will scroll from top


//        $("#header").css('background-color', '#fff').css('boxShadow','8px 5px 8px rgba(0,0,0,.1)');

    $(document).scroll(function() {
      var thisWidth = $(this).width();
        // background color will go transparent if width of the window is less than 700px else white
        if (thisWidth < 700) {
            $('#header').css('background-color', 'rgba(255,255,255,.8)');
        } else {
            // default setting for desktop here...
            $('#header').css('background-color', '#fff').css('boxShadow','8px 5px 8px rgba(0,0,0,.1)');
        }
    });

// +++++++++++++++++++ WORK gallery button SECTION++++++++++++++++++++++

// when all button is cliked
$("#fa-all").click(function(e){
e.preventDefault() ;// to prevent the window open in different browder on user click event
//to give a border botton on active button
$(this).css("borderBottom", "2px solid #165548");
$("#fa-wordpress").css("borderBottom", "none");
$("#fa-angular").css("borderBottom", "none");
$("#fa-jquery").css("borderBottom", "none");

$(".all").css("display", "block");
$(".wordpress").css("display", "none");
});



// when wordpress button is clicked
$("#fa-wordpress").click(function(e){
e.preventDefault() ;// to prevent the window open in different browder on user click event
//to give a border botton on active button
$(this).css("borderBottom", "2px solid #165548");
$("#fa-all").css("borderBottom", "none");
$("#fa-angular").css("borderBottom", "none");
$("#fa-jquery").css("borderBottom", "none");


$(".all").css("display", "none");
$(".wordpress").css("display", "block");
});

// when angular js is clicked
$("#fa-angular").click(function(e){
e.preventDefault() ;// to prevent the window open in different browder on user click event

//to give a border botton on active button
$(this).css("borderBottom", "2px solid #165548");
$("#fa-wordpress").css("borderBottom", "none");
$("#fa-all").css("borderBottom", "none");
$("#fa-jquery").css("borderBottom", "none");

$(".all").css("display", "none");
$(".wordpress").css("display", "none");
$(".jquery").css("display", "none");

$(".angular").css("display", "block");
});

// when jquery  is clicked
$("#fa-jquery").click(function(e){
e.preventDefault() ;// to prevent the window open in different browder on user click event

//to give a border botton on active button
$(this).css("borderBottom", "2px solid #165548");
$("#fa-wordpress").css("borderBottom", "none");
$("#fa-all").css("borderBottom", "none");
$("#fa-angular").css("borderBottom", "none");

$(".all").css("display", "none");
$(".wordpress").css("display", "none");
$(".angular").css("display", "none");

$(".jquery").css("display", "block");
});


//* to make smooth scroll  on click  */
// $('a[href^="#"]').on('click',function (e) {
// 	    e.preventDefault();
//
// 	    var target = this.hash;
// 	    var $target = $(target);
//
// 	    $('html, body').stop().animate({
// 	        'scrollTop': $target.offset().top
// 	    }, 2000, 'swing', function () {
// 	        window.location.hash = target;
// 	    });
// 	});

// jwuery ui for tabs
  $( function() {
     $( "#tabs" ).tabs();
   } );

   $('.tab-panels').tabs({
        select: function(event, ui) {
            $(ui.panel).animate({opacity:0.1});
        },
        show: function(event, ui) {
            $(ui.panel).animate({opacity:1.0},4000);
        }


});


})// end of document ready
