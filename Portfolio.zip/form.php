<?php

if(isset($_POST['submit'])){
    $name=$_POST['name'];
    $emailForm=$_POST['email'];
    $message=$_POST['msg'];
    
    $mailTo='payelbanerjee9@yahoo.com';
    $headers="Form: ".$emailForm;
    $subject='Form Submition';
    $txt="Name: ".$name."\n\n".$headers."\n\n"."Message: ".$message ;
    
    
    if(mail($mailTo,$subject,$txt,$headers)){
       echo ("message successfully sent!");
    }else{
        echo ("message not sent!Please try again!");
    }
    
   
}

?>