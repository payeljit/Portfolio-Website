<?php
$msg = "";
if(isset($_ POST['submit'])){
    require 'phpmailer/PHPMailerAutoload.php';
    
    function sendemail($to, $form, $formName, $body){
        $mail = new  PHPMailer();
        $mail->setForm($form, $formName);
        $mail->addAdress($to);
        $mail->Subject = 'Contact form -Email';
        $mail->Body = $body;
        
        $mail->isHTML(isHtml: false);
        
        return $mail->send();
    }
    
    $name = $_POST['username'];
    $email = $_POST['email'];
    $body = $_POST['body'];
    
    if(sendemail(to:'payeljit89@gmail.com', $email, $name, $body)){
        $msg = 'Email sent';
    }else{
       $msg = 'Email faile!'; 
    }
}
?>

<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <title>Document</title>

</head>

<body>

 
          <form method="post" id="contact-form" action="contactform.php" enctype="multipart/form-data">
            <div class="form-group">
              <i class="fa fa-user"></i>
                <input type="text" class="form-control" id="formGroupInput" placeholder="Name" name="username" required>
                   </div>
                   
                    <div class="form-group">
                    <i class="fa fa-at"></i>
                    <input type="email" class="form-control" id="formGroupInput2" placeholder="Email" name="email" required>
                   </div>
            <i class="fa fa-envelope"></i>
            <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" placeholder="Message" name="body" required></textarea>
             <input type="submit" name="submit" value="Send Email">
         </form>   
<? echo $msg;   ?>
</body>

</html>

